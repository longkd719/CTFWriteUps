sudo docker-compose up

curl -X 'POST' --data-binary 'email=admin%40admin.com&username=admin&password=admin&passwordConf=admin' http://localhost:1337/